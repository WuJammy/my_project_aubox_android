package com.example.lebox;

import androidx.annotation.NonNull;
import androidx.camera.camera2.internal.PreviewConfigProvider;
import androidx.camera.core.Camera;
import androidx.camera.core.CameraSelector;
import androidx.camera.core.CameraX;
import androidx.camera.core.ImageAnalysis;
import androidx.camera.core.ImageCapture;
import androidx.camera.core.ImageCaptureException;
import androidx.camera.core.Preview;
import androidx.camera.core.impl.ImageAnalysisConfig;
import androidx.camera.core.impl.ImageCaptureConfig;
import androidx.camera.core.impl.ImageOutputConfig;
import androidx.camera.core.impl.PreviewConfig;
import androidx.camera.lifecycle.ProcessCameraProvider;
import androidx.camera.view.PreviewView;
import androidx.core.content.ContextCompat;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.LifecycleOwner;
import androidx.lifecycle.LifecycleRegistry;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.hardware.camera2.CameraCaptureSession;
import android.hardware.camera2.CameraDevice;
import android.media.ImageReader;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.text.AlteredCharSequence;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.content.Intent;
import android.widget.ImageView;
import android.widget.Toast;

import com.camerakit.CameraKitView;
import com.google.common.util.concurrent.ListenableFuture;
import com.google.zxing.integration.android.IntentIntegrator;
import com.google.zxing.integration.android.IntentResult;
import com.squareup.okhttp.Callback;
import com.squareup.okhttp.OkHttpClient;
import com.squareup.okhttp.Request;
import com.squareup.okhttp.Response;


import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Semaphore;

import static android.os.Environment.DIRECTORY_DCIM;


public class MainActivity extends Activity {

    private Button ViewPageButton, ScanPageButton;
    private ImageCapture imageCapture;
    //ImageCapture imageCapture = new ImageCapture.Builder().setTargetRotation();
    private int lensFacing = CameraSelector.LENS_FACING_FRONT;
    //PreviewConfig.Builder configBuilder = new PreviewConfig().Builder<B>().setLensFacing(CameraSelector.LENS_FACING_FRONT);

    public String str;
    OkHttpClient client = new OkHttpClient();
    Request request = new Request.Builder().url("http://120.101.8.52/aubox604/WebService1.asmx/ifvideo?boxnumber=123").build();
    private LifecycleOwner my;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        intialUi();
        changePage();
    }

    @Override
    protected void onStart() {
        super.onStart();
        getstr thread = new getstr();
        thread.start();
    }

    class getstr extends Thread {
        @Override
        public void run() {
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Request request, IOException e) {

                }

                @Override
                public void onResponse(Response response) throws IOException {
                    str = response.body().string();
                    System.out.println(str);
                }
            });

        }

    }

    private void intialUi() {
        ViewPageButton = findViewById(R.id.btn_view);
        ScanPageButton = findViewById(R.id.btn_scan);

    }//初始化ui

    private void scanFrameSet() {
        IntentIntegrator integrator = new IntentIntegrator(this);
        integrator.setDesiredBarcodeFormats(IntentIntegrator.QR_CODE_TYPES);//選擇掃描qrcode
        integrator.setCameraId(1);//相機前後鏡頭調整，1為前鏡頭，0為後鏡頭
        integrator.setCaptureActivity(Scan.class);//抓取自己定義的頁面
        integrator.setBeepEnabled(false);//掃描後有沒有提示音
        integrator.setBarcodeImageEnabled(false);
        integrator.setPrompt(" ");//最下方的提示字
        integrator.initiateScan();//初始化掃描設定
    } //掃描條碼之設定

    private void setDiaolgString(String scanResult) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);//設定對話框內容
        builder.setTitle("掃描結果");//對話框標題
        builder.setMessage("掃描結果:" + scanResult + ":正確");//對話框內容
        builder.setPositiveButton("確定", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {          //點擊確定後跳轉至視訊頁
                Intent intentv = new Intent();
                intentv.setClass(MainActivity.this, view.class);
                startActivity(intentv);
            }
        });//對話框按鈕

        AlertDialog dialog = builder.create();
        dialog.show();//顯示對話框


    }//傳送文字至對話框內容中

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        IntentResult result = IntentIntegrator.parseActivityResult(requestCode, resultCode, data);
        if (result != null) {
            if (result.getContents() == null) {
                Toast.makeText(this, "You cancelled the scanning", Toast.LENGTH_SHORT).show();
            } else {
                setDiaolgString(result.getContents());//顯示掃描結果於對話框

            }
        } else {
            super.onActivityResult(requestCode, resultCode, data);
        }
    }//掃描後執行之動作

    private void changePage() {
        ViewPageButton.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intentv = new Intent();
                intentv.setClass(MainActivity.this, view.class);
                startActivity(intentv);
            }
        });//換到視訊頁


        ScanPageButton.setOnClickListener(new android.view.View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // take_photo();
                System.out.println("Scan Button Success");

                SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");//抓取當下日期
                Date curDate = new Date(System.currentTimeMillis());//抓取當下時間
                String str = sDateFormat.format(curDate);//當下日期+時間的字串
                ImageCapture.OutputFileOptions outputFileOptions = new ImageCapture.OutputFileOptions.Builder(
                        new File(Environment.getExternalStorageDirectory(), str + ".jpg")).build();//儲存空間的建立


                //  ImageCaptureConfig configg = new ImageCaptureConfig().Builder


                /*cameraView.captureImage(new CameraKitView.ImageCallback() {

                    @Override
                    public void onImage(CameraKitView cameraKitView, final byte[] capturedImage) {

                        System.out.println("Capture Photo Success");

                        SimpleDateFormat sDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");//抓取當下日期
                        Date curDate = new Date(System.currentTimeMillis());//抓取當下時間
                        String str = sDateFormat.format(curDate);//當下日期+時間的字串
                        File savedPhoto = new File(Environment.getExternalStorageDirectory(),  str+".jpg");//儲存空間的路徑


                        try {
                            FileOutputStream outputStream = new FileOutputStream(savedPhoto.getPath());//輸出相片
                            outputStream.write(capturedImage);//寫入手機內記憶體
                            outputStream.close();//關閉輸出的動作
                        } catch (IOException e) {
                            e.printStackTrace();
                            System.out.println("Save Photo Failed");
                            }

                        }
                });//拍照並儲存相片到手機內部*/
                scanFrameSet();
                //Intent intents=new Intent();
                //intents.setClass(MainActivity.this,Scan.class);
                //startActivity(intents);
            }
        });//換到掃描頁


    }


    private void startcamera() {
        // Preview preview = new Preview.Builder().build();
        //Camera camera = cameraProvider.bindToLifecycle(lifecycleOwner, cameraSelector, preview);
        //ImageCapture.OutputFileOptions outputFileOptions = new  ImageCapture.OutputFileOptions.Builder(n).build();

        ListenableFuture cameraProviderFuture = ProcessCameraProvider.getInstance(this);

        cameraProviderFuture.addListener(() -> {
            try {
                ProcessCameraProvider cameraProvider = (ProcessCameraProvider) cameraProviderFuture.get();

                Preview preview = new Preview.Builder().build();
                PreviewView previewView = findViewById(R.id.preview_view);

                imageCapture = new ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MINIMIZE_LATENCY).build();



                CameraSelector cameraSelector = new CameraSelector.Builder().requireLensFacing(CameraSelector.LENS_FACING_FRONT).build();

                // Attach use cases to the camera with the same lifecycle owner
                Camera camera = cameraProvider.bindToLifecycle(this, cameraSelector, preview, imageCapture);

                // Connect the preview use case to the previewView
                preview.setSurfaceProvider(previewView.createSurfaceProvider(camera.getCameraInfo()));


            } catch (InterruptedException | ExecutionException e) {
                // Currently no exceptions thrown. cameraProviderFuture.get() should
                // not block since the listener is being called, so no need to
                // handle InterruptedException.
            }
        }, ContextCompat.getMainExecutor(this));


    }


}









